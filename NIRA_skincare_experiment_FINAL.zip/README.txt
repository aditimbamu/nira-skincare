NIRA SKINCARE EXPERIMENT — PROJECT PACKAGE

This version keeps the existing Google Apps Script endpoint and response columns while upgrading the website into a more polished skincare research prototype.

FILES
- index.html: responsive NIRA website, product collection, filters, product detail modal, bag, skin quiz, recommendation engine, feedback form.
- google_apps_script.gs: Google Apps Script endpoint used to append research responses to the "Responses" sheet.

GOOGLE SHEETS
The endpoint already configured in index.html is:
https://script.google.com/macros/s/AKfycbwVnmlHPsFJq-8c81jFFXduHo7V514MoUhm42T4jGjYlPYRwJ5nT-M9AcBV-eSmlHux/exec

If you deploy a new Apps Script, replace GOOGLE_SHEET_ENDPOINT in index.html with the new /exec URL.

RESEARCH NOTE
All NIRA products, prices, ingredient combinations and reviews are fictional research stimuli for the student project. No payment is processed and the form collects no identifying personal information.
