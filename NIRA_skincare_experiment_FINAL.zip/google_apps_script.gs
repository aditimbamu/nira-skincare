function doGet(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Responses");
  const p = e.parameter;
  sheet.appendRow([
    new Date(), p.participant_id || "", p.group || "", p.skin_type || "",
    p.goal || "", p.budget || "", p.usage || "", p.products_selected || "",
    p.number_products || "", p.cart_value || "", p.purchase_decision || "",
    p.confidence || "", p.ease || "", p.relevance || "", p.decision_time_seconds || ""
  ]);
  return ContentService.createTextOutput("OK");
}
